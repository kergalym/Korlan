"""

RenderPipeline

Copyright (c) 2014-2016 tobspr <tobias.springer1@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

"""

from panda3d.core import OmniBoundingVolume, Texture, Mat4, SamplerState, Vec3, PTALMatrix4f, PTAVecBase3f
from Engine.Render.rpcore.pluginbase.base_plugin import BasePlugin
from Engine.Render.rpcore.globals import Globals
from Engine.Render.rpplugins.waterfft.water_stage import WaterStage


class Plugin(BasePlugin):

    name = "Ambient Occlusion"
    author = "kergalym <housegregory299@gmail.com>"
    description = "GPU FFT-based water plugin"
    version = "1.0"

    def on_stage_setup(self):
        if self.is_plugin_enabled("water_fft"):
            self.water_level = self.get_setting("water_level")
            self.model = Globals.base.loader.load_model("/$$rp/data/builtin_models/water/water_grid.bam")
            self.model.reparent_to(Globals.base.render)
            self.model.node().set_final(True)
            self.model.node().set_bounds(OmniBoundingVolume())
            self.model.set_two_sided(True)
            self.model.set_shader_input("waterHeight", self.water_level)
            self.model.set_mat(Mat4.identMat())
            self.model.clear_transform()

            foam = Globals.base.loader.load_texture("/$$rp/data/builtin_models/water/water_foam.png")
            self.model.set_shader_input("waterFoam", foam)

            self.stage = self.create_stage(WaterStage)
            self.stage.setup()
            self.stage.update()

            self.model.set_shader_input("waterHeightfield", self.stage.get_displacement_texture())
            self.model.set_shader_input("waterNormal", self.stage.get_normal_texture())

            # Set texture filter modes
            for tex in [foam, self.stage.get_displacement_texture(), self.stage.get_normal_texture()]:
                tex.set_wrap_u(SamplerState.WMRepeat)
                tex.set_wrap_u(SamplerState.WMRepeat)
                tex.set_minfilter(SamplerState.FTLinearMipmapLinear)
                tex.set_magfilter(SamplerState.FTLinearMipmapLinear)

            self.pipeline = pipeline

            self.pipeline.set_effect(self.model, "/$$rp/effects/projected_water.yaml", {
                # "render_shadow": False
            })
            self.model.set_shader_input("cameraPosition", base.camera.get_pos(render))
            self.model.set_shader_input("currentMVP", self.model.get_mat())
            self.model.set_shader_input("waterHeight", self.water_level)

    def update_task(self, task):
        self.stage.update()
        return task.cont

    def on_post_stage_setup(self):
        if self.is_plugin_enabled("water_fft"):
            self.get_plugin_instance("water_fft").capture_stage.required_inputs.append("camera_pos")
            self.get_plugin_instance("water_fft").capture_stage.required_pipes.append("view_proj_mat_no_jitter")
            Globals.base.add_task(self.update_task, "update_water")
