from panda3d.core import OmniBoundingVolume, Texture, Mat4, SamplerState, Vec3, PTALMatrix4f, PTAVecBase3f

from Engine.Render.rpcore.globals import Globals
from Engine.Render.rpcore.water.water_manager import WaterManager


class ProjectedWaterGrid:

    def __init__(self, pipeline):

        self.water_level = 0.0
        self.model = Globals.base.loader.load_model("/$$rp/data/builtin_models/water/water_grid.bam")
        self.model.reparent_to(Globals.base.render)
        self.model.node().set_final(True)
        self.model.node().set_bounds(OmniBoundingVolume())
        self.model.set_two_sided(True)
        self.model.set_shader_input("waterHeight", self.water_level)
        self.model.set_mat(Mat4.identMat())
        self.model.clear_transform()

        foam = Globals.base.loader.load_texture("/$$rp/data/builtin_models/water/water_foam.png")
        self.model.set_shader_input("waterFoam", foam)       

        self.manager = WaterManager()
        self.manager.setup()
        self.manager.update()

        self.model.set_shader_input("waterHeightfield", self.manager.get_displacement_texture())
        self.model.set_shader_input("waterNormal", self.manager.get_normal_texture())

        # Set texture filter modes
        for tex in [foam, self.manager.get_displacement_texture(), self.manager.get_normal_texture()]:
            tex.set_wrap_u(SamplerState.WMRepeat)
            tex.set_wrap_u(SamplerState.WMRepeat)
            tex.set_minfilter(SamplerState.FTLinearMipmapLinear)
            tex.set_magfilter(SamplerState.FTLinearMipmapLinear)

        self.pipeline = pipeline

        self.pipeline.set_effect(self.model, "/$$rp/effects/projected_water.yaml", {
            # "render_shadow": False
        })
        self.model.set_shader_input("cameraPosition", base.camera.get_pos(render))
        self.model.set_shader_input("currentMVP", self.model.get_mat())

        """self.pipeline.set_effect(self.model, "/$$rp/effects/projected_water_shadows.yaml", {})
        self.model.set_shader_input("cameraPosition", PTAVecBase3f.emptyArray(1))
        self.model.set_shader_input("currentMVP", PTALMatrix4f.emptyArray(1))"""

        # self.model.set_shader_input("cameraPosition", base.camera.get_pos())
        # self.model.set_shader_input("currentMVP", self.model.get_mat())

        Globals.base.add_task(self.update_task, "update_water")

    def set_water_level(self, level):
        self.water_level = level
        self.model.set_shader_input("waterHeight", level)

    def update_task(self, task):
        self.manager.update()
        return task.cont
